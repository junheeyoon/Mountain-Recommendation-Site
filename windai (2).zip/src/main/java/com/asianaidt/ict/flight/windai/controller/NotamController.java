package com.asianaidt.ict.flight.windai.controller;


import com.asianaidt.ict.flight.windai.data.Notam;
import com.asianaidt.ict.flight.windai.data.ResponseNotam;
import com.asianaidt.ict.flight.windai.service.NotamService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class NotamController {  
  private final NotamService notamService;

  public NotamController(NotamService notamService) {
    this.notamService = notamService;
  }

  @GetMapping("/wnda_ie/api/v1.0/e_score")
  public ResponseNotam getScore(Notam notam) throws Exception {
    log.debug("REQUEST | " + notam.toString());
    ResponseNotam responseNotam = new ResponseNotam(notam, notamService.getScore(notam));
    log.debug("RESPONSE | " + responseNotam.toString());
    return responseNotam;
  }
}