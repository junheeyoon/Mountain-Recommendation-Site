package com.asianaidt.ict.flight.windai.data;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ResponseNotam extends Notam {
  @JsonProperty("e_score")
  private String score;

  public ResponseNotam(Notam notam, String score) {
    super(notam);
    this.score = score;
  }

  public ResponseNotam(Notam notam, double score) {
    super(notam);
    this.score = String.valueOf(score);
  }

  public String toString() {
    return String.format("ResponseNotam(id=%s, score=%s)", getId(), getScore());
  }
}