package com.asianaidt.ict.flight.windai.model;

import com.asianaidt.ict.flight.windai.data.Notam;

import java.util.List;

public interface Predict {
  List<Double> score(final Notam notam);
  boolean reload();
}