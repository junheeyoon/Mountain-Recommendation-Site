package com.asianaidt.ict.flight.windai.model;

import com.asianaidt.ict.flight.windai.data.Notam;
import com.mayabot.mynlp.fasttext.FastText;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
@ConfigurationProperties("notam.fasttext")
@Setter
public class Fasttext implements Predict {
  private final String FILENAME_SEPARATOR = "_";
  @Value("${notam.rootpath}")
  private String rootpath;
  private String prefix;
  private List<String> users;
  private String suffix;
  private List<FastText> fasttexts = new ArrayList<>();

  @PostConstruct
  public void init() {
    try {
      for (final String user : users) {
        final Path path = Paths.get(rootpath, prefix + FILENAME_SEPARATOR + user + FILENAME_SEPARATOR + suffix);
        fasttexts.add(FastText.loadFasttextBinModel(path.toFile()));
        log.debug("INIT | " + path.toString());
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Override
  public List<Double> score(final Notam notam) {
    return fasttexts.stream()
      .map(f -> f.predict(notam.paramForFastText(), 1))
      .map(p -> Double.parseDouble(p.get(0).second.replace("__label__", "")))
      .collect(Collectors.toList());
  }

  @Override
  public boolean reload() {
    fasttexts.clear();
    init();
    return true;
  }
}