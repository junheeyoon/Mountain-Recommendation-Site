package com.asianaidt.ict.flight.windai.service;

import com.asianaidt.ict.flight.windai.data.Notam;
import com.asianaidt.ict.flight.windai.model.Fasttext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class NotamService {
  private final Fasttext fastText;

  @Autowired
  public NotamService(Fasttext fastText) {
    this.fastText = fastText;
  }

  public double getScore(Notam notam) throws Exception {
    List<Double> textScore = fastText.score(notam);

    log.debug("TEXT SCORE | " + textScore.stream().map(String::valueOf).collect(Collectors.joining(",")));
    List<Double> totalScore = new ArrayList<>();
    for (int i = 0; i < textScore.size(); i++) {
      totalScore.add(textScore.get(i));
    }
    return totalScore.stream().mapToDouble(v -> v).average().orElse(0);
  }

  public List<Double> getScores(Notam notam) {
    List<Double> textScore = fastText.score(notam);
    return textScore;
  }


  public boolean reloadModel() {
    return fastText.reload();
  }
}