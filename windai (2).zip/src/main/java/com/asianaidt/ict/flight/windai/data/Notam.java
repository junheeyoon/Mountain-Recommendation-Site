package com.asianaidt.ict.flight.windai.data;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Notam {
  @JsonProperty("id_windai")
  private String id;
  @JsonProperty("e_section")
  String e;

  public Notam(final Notam notam) {
    this.id = notam.id;
    this.e  = notam.e;
  }

  public void setId_windai(String v) { this.id = v.toUpperCase(); }
  public void setE_section(String v) { this.e = v.toUpperCase(); }

  public List<String> paramForFastText() {
    return Arrays.asList(pretreatment(e));
  }

  public List<String> paramForWordCount() {
    List<String> param = new ArrayList<>();
    param.addAll(Arrays.asList(e.split(" ")));
    return param;
  }

  private String pretreatment(String str) {
    String rep = str.replace("\\.+",".")
        .replace("\\d{1}\\.{1}\\s+"," ")
        .replace("\\d{1}\\.{1}[a-zA-Z]"," ")
        .replace("\\s+\\.{1}\\s+"," ")
        .replace("[,]+"," ")
        .replace("http[s]{0,1}[:]{0,1}//"," ")
        .replace("[:]+"," ")
        .replace("(-{2,3}[a-zA-Z]+-{2,3})"," ")
        .replace("-+"," ")
        .replace("("," ")
        .replace(")"," ")
        .replace("/[ ]+"," ")
        .replace("/{3}","/")
        .replace("rwy","rwy ")
        .replace("runway","runway ")
        .replace("runways","runway ")
        .replace("twy","twy ")
        .replace("taxiway","taxiway ")
        .replace("[ ]+"," ")
        .toLowerCase();
    System.out.println(str);
    System.out.println(rep);
    return rep;
  }
}