package com.asianaidt.ict.flight.windai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WindaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
